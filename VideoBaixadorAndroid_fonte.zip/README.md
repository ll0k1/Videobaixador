# Vídeo Baixador — projeto Android

Aplicativo Android nativo simples para colar links públicos de Instagram/TikTok, baixar e ver uma lista dos arquivos baixados.

## Importante
Este pacote é o **código-fonte Android**, não um APK já compilado. O ambiente de criação não tem o Android SDK/Gradle necessários para gerar e testar um APK assinado. O projeto precisa ser aberto no Android Studio para compilar.

## Como gerar o APK
1. Instale Android Studio: https://developer.android.com/studio
2. Extraia o ZIP e abra a pasta `VideoBaixadorAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e a configuração do Android SDK 35.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

O plugin Chaquopy baixa o Python e instala `yt-dlp` durante a compilação, por isso a primeira compilação exige internet.

## Limitações conhecidas
- Baixa para a pasta privada de arquivos do aplicativo; os arquivos podem não aparecer automaticamente na galeria.
- A lista é atualizada ao concluir um download e ao abrir o app.
- A versão inicial não oferece download em segundo plano nem FFmpeg para combinar fluxos separados.
- Sites mudam com frequência e alguns vídeos podem falhar, mesmo públicos.
- Use apenas vídeos próprios ou com permissão para baixar. Respeite direitos autorais e os termos das plataformas.
- Este projeto ainda precisa ser compilado e testado num dispositivo real; não é um APK pronto para instalar.
