import os
import glob
import yt_dlp

def download(url, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    before = set(glob.glob(os.path.join(output_dir, "*")))
    opts = {
        "outtmpl": os.path.join(output_dir, "%(title).120B [%(id)s].%(ext)s"),
        "format": "best[ext=mp4]/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": False,
        "retries": 2,
        "socket_timeout": 25,
        "restrictfilenames": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
        after = set(glob.glob(os.path.join(output_dir, "*")))
        new_files = [p for p in (after - before) if os.path.isfile(p)]
        if new_files:
            return "Download concluído! Veja em Meus downloads."
        return "O download terminou, mas não encontrei um arquivo novo."
    except Exception as exc:
        msg = str(exc).replace("\n", " ")
        if len(msg) > 220:
            msg = msg[:220] + "…"
        return "Não foi possível baixar. O vídeo pode ser privado, restrito ou incompatível. " + msg
